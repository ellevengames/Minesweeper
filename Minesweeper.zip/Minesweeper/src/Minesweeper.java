import java.util.*;
import java.lang.*;

public class Minesweeper {
   public static void main(String[] args){
      ConsoleColors cc = new ConsoleColors();
      Scanner scan = new Scanner(System.in);
      System.out.println(cc.RED_BOLD + "WELCOME TO MINESWEEPER" + cc.RESET);
      System.out.println(cc.GREEN + "Enter the Board size (X Value, 4 through 54): " + cc.RESET);
      int x = scan.nextInt();
      if(x < 4 || 55 < x){
         System.err.println("Not a valid Size! (Error 1)");
         return;
      }
      System.out.println(cc.GREEN + "Enter the Board size (Y Value, 4 through 54): " + cc.RESET);
      int y = scan.nextInt();
      if(y < 4 || 55 < y){
         System.err.println("Not a valid Size! (Error 2)");
         return;
      }
      String[][] field = Minefield.initMinefield(x, y);
      int totalSize = x*y;
      int bombs = totalSize/9;
      String[][] fieldBackEnd = Minefield.initMinefield(bombs, x, y);
      System.out.println(cc.GREEN_BRIGHT + "Input Coordinates in X Y form!" + cc.RESET);
      System.out.println(Minefield.mfToString(field));
      System.out.println(cc.CYAN_BOLD + "This is the game board. Enter Coordinates to check points for bombs. If you hit a bomb, you lose. Good Luck!" + cc.RESET);
      boolean gameEnd = PlayMF.Play(field, fieldBackEnd, totalSize, bombs);
      if(gameEnd){
         System.out.println(cc.BLUE_BOLD + "You Win!" + cc.RESET);
      }
      else{
         System.out.println(cc.RED_BOLD + "You Lose!" + cc.RESET);
      }
   }

}