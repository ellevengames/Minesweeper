import java.lang.*;

public class Minefield {
   private static String[][] mffe;
   private static String[][] mf;
   public static String[][] initMinefield(int b, int x, int y){
      mf = new String[y][x];
      for(int r = 0; r < mf.length; r++){
         for(int c = 0; c < mf[0].length; c++){
            mf[r][c] = "0";
         }
      }
      int rng;
      boolean hasRun = false;
      while(b>0){
         if(!hasRun) {
            for(int r = 0; r < mf.length; r++){
               for(int c = 0; c < mf[0].length; c++){
                  rng = (int) (Math.random() * 9 + 1);
                  if (rng == 9) {
                     mf[r][c] = "B";
                     b--;

                  }

               }
            }
            hasRun = true;
         }
         else{
            for(int r = 0; r < mf.length; r++){
               for(int c = 0; c < mf[0].length; c++){
                  rng = (int) (Math.random() * 9 + 1);
                  if (rng == 9 && !(mf[r][c].equals("B"))) {
                     mf[r][c] = "B";
                     b--;

                  }

               }
            }
         }
      } // i forgot the logic here
      for(int r = 0; r < mf.length; r++){
         for(int c = 0; c < mf[0].length; c++){
            if(!(mf[r][c].equals("B"))){
               mf[r][c] = NUM_ASSIGN(r,c) + "";
            }
         }
      }
      return mf;
   }
   // Sets up the numbers of bombs around a spot //
   private static int NUM_ASSIGN(int r, int c){
      int bHere = 0;
      if(r == 0 && c == 0){
         if(mf[r+1][c].equals("B")){
            bHere++;
         }
         if(mf[r][c+1].equals("B")){
            bHere++;
         }
         if(mf[r+1][c+1].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else if(r == 0 && c == mf[0].length-1){
         if(mf[r+1][c].equals("B")){
            bHere++;
         }
         if(mf[r+1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r][c-1].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else if(r == mf.length-1 && c == 0){
         if(mf[r-1][c].equals("B")){
            bHere++;
         }
         if(mf[r-1][c+1].equals("B")){
            bHere++;
         }
         if(mf[r][c+1].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else if(r == mf.length-1 && c == mf[0].length-1){
         if(mf[r-1][c].equals("B")){
            bHere++;
         }
         if(mf[r-1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r][c-1].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else if(r == 0){
         if(mf[r+1][c].equals("B")){
            bHere++;
         }
         if(mf[r][c+1].equals("B")){
            bHere++;
         }
         if(mf[r+1][c+1].equals("B")){
            bHere++;
         }
         if(mf[r+1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r][c-1].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else if(r == mf.length-1){
         if(mf[r-1][c].equals("B")){
            bHere++;
         }
         if(mf[r][c+1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c+1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r][c-1].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else if(c == 0){
         if(mf[r+1][c].equals("B")){
            bHere++;
         }
         if(mf[r][c+1].equals("B")){
            bHere++;
         }
         if(mf[r+1][c+1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c+1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else if(c == mf[0].length-1){
         if(mf[r+1][c].equals("B")){
            bHere++;
         }
         if(mf[r][c-1].equals("B")){
            bHere++;
         }
         if(mf[r+1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c].equals("B")){
            bHere++;
         }
         return bHere;
      }
      else{
         if(mf[r+1][c].equals("B")){
            bHere++;
         }
         if(mf[r][c-1].equals("B")){
            bHere++;
         }
         if(mf[r+1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c-1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c].equals("B")){
            bHere++;
         }
         if(mf[r][c+1].equals("B")){
            bHere++;
         }
         if(mf[r+1][c+1].equals("B")){
            bHere++;
         }
         if(mf[r-1][c+1].equals("B")){
            bHere++;
         }
         return bHere;
      }
   }
   public static String[][] initMinefield(int x, int y){
      mffe = new String[y][x];
      for(int r = 0; r < y; r++)
         for (int c = 0; c < x; c++)
            mffe[r][c] = "+";
      return mffe;
   }
   public static String mfToString(String[][] m){
      ConsoleColors cc = new ConsoleColors();
      String ret = "";
      for (String[] i:m) {
         ret+= cc.YELLOW;
         for (String k : i)
            ret += k + " ";
         ret+= cc.RESET + "\n";
      }
      return ret;
   }
}