import java.util.*;

public class PlayMF {
   public static boolean Play(String[][] mffe, String[][] mfbe, int totS, int bombs){
      int totClickable = totS - bombs;
      Scanner scan = new Scanner(System.in);
      ConsoleColors cc = new ConsoleColors();
      while(totClickable > 0){
         System.out.println();
         System.out.println(cc.GREEN + "Enter Coordinates!" + cc.RESET);
         int x = scan.nextInt()-1;
         int y = scan.nextInt()-1;
         mffe[y][x] = mfbe[y][x];
         System.out.println(Minefield.mfToString(mffe));
         if(mfbe[y][x].equals("B")){
            return false;
         }
         totClickable--;
      }
      return true;
   }
}
