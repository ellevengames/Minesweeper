import java.util.*;

public class PlayMF {
   public static boolean Play(String[][] mffe, String[][] mfbe, int totS, int bombs){
      int totClickable = totS - bombs;
      Scanner scan = new Scanner(System.in);
      ConsoleColors cc = new ConsoleColors();
      while(totClickable > 0){
         System.out.println();
         System.out.println(cc.GREEN + "Enter Coordinates! (0 0 to enter flag mode)" + cc.RESET);
         int x = scan.nextInt();
         int y = scan.nextInt();
         if(x == 0 && y == 0){
            mffe = flagMode(mffe);
         }
         else {
            x--;
            y--;
            if(mffe[y][x].equals("+")){
               totClickable--;
            }
            mffe[y][x] = mfbe[y][x];
            System.out.println(Minefield.mfToString(mffe));
            if (mfbe[y][x].equals("B")) {
               return false;
            }
         }
      }
      return true;
   }
   public static String[][] flagMode(String[][] mffe){
      ConsoleColors cc = new ConsoleColors();
      Scanner scan = new Scanner(System.in);
      while(true){
         System.out.println(cc.GREEN + "Enter Coordinates! (0 0 to exit flag mode)" + cc.RESET);
         int x = scan.nextInt();
         int y = scan.nextInt();
         if(x == 0 && y == 0){
            return mffe;
         }
         else {
            x--;
            y--;
            mffe[y][x] = "F";
            System.out.println(Minefield.mfToString(mffe));
         }
      }
   }
}
